//
//  main.m
//
//  Created by Chuck Houpt on Wed Oct 19 2005.
//  Copyright (c) 2005-2006 Chuck Houpt. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
