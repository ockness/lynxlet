#!/bin/bash

# Copyright (c) 2005-2006 Chuck Houpt. All rights reserved.

set -eux

# Setup reasonable defaults when running outside XCode.
BUILD_DIR=${BUILD_DIR:-$PWD/build}
PROJECT_DIR=${PROJECT_DIR:-$PWD}
SDKROOT_ppc=${SDKROOT_ppc:-/Developer/SDKs/MacOSX10.3.9.sdk}
SDKROOT_i386=${SDKROOT_i386:-/Developer/SDKs/MacOSX10.4u.sdk}

# Set up reasonable default when running outside mutibuild.sh
ARCH=${ARCH:-ppc}
export MULTIBUILD_NCPU=${MULTIBUILD_NCPU:-`sysctl -n hw.ncpu`}


SOURCE_CACHE="$HOME/Library/Caches/net.habilis.source"

GETTEXT_VERSION=gettext-0.12.1
GETTEXT_URL=http://ftp.gnu.org/pub/gnu/gettext/$GETTEXT_VERSION.tar.gz
GETTEXT_TARBALL=`basename $GETTEXT_URL`
PREFIX="$BUILD_DIR"/gettext

	SRC_DIR="$BUILD_DIR"/$ARCH/$GETTEXT_VERSION
	EXEC_PREFIX="$PREFIX"/$ARCH
	
	eval SDKROOT=\$SDKROOT_$ARCH

	if [ ! -f "$EXEC_PREFIX"/bin/gettext ]
	then

		pushd "$BUILD_DIR"

		if [ ! -r "$SOURCE_CACHE"/$GETTEXT_TARBALL ]
		then
			mkdir -p "$SOURCE_CACHE"
			pushd "$SOURCE_CACHE"
			curl -sO $GETTEXT_URL
			popd
		fi

		if [ ! -d "$SRC_DIR" ]
		then
			mkdir -p "$BUILD_DIR"/"$ARCH"
			pushd "$BUILD_DIR"/"$ARCH"
			tar xzf "$SOURCE_CACHE"/$GETTEXT_TARBALL
			popd
		fi

		pushd "$SRC_DIR"

		# Setup for 10.2+ compilation. See:
		# http://developer.apple.com/technotes/tn2005/tn2137.html
		#export CFLAGS='-O -isysroot /Developer/SDKs/MacOSX10.2.8.sdk'
		#export LDFLAGS='-Wl,-syslibroot,/Developer/SDKs/MacOSX10.2.8.sdk'

		# Setup for 10.3+ compilation.
#		export CFLAGS='-O -isysroot /Developer/SDKs/MacOSX10.3.9.sdk'
#		export LDFLAGS='-Wl,-syslibroot,/Developer/SDKs/MacOSX10.3.9.sdk'

#		export CC="gcc -arch $ARCH"
#		export CFLAGS="-arch $ARCH -O -isysroot $SDKROOT"
#		export CXXFLAGS="-arch $ARCH -O -isysroot $SDKROOT"
#		export LDFLAGS="-arch $ARCH -Wl,-syslibroot,$SDKROOT"

		# Make the arch flags part of CC/CXX, because gettext 1.2's old libtool doesn't
		# include CFLAGS when linking dynamic libraries.
		export CC="gcc -arch $ARCH"
		export CXX="g++ -arch $ARCH"
		export CFLAGS="-Os -isysroot $SDKROOT"
		export CXXFLAGS="-Os -isysroot $SDKROOT"
		export LDFLAGS="-arch $ARCH -Wl,-syslibroot,$SDKROOT"
		
		time ./configure --prefix="$PREFIX" --exec-prefix="$EXEC_PREFIX" --disable-dependency-tracking

		time make -j $MULTIBUILD_NCPU
		# Install seperately on single job, because gettext-0.16.1 install fails when done in parallel
		time make install
		popd
		popd

	fi
