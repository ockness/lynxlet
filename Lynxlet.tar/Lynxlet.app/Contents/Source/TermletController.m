//
//  TermletController.m
//  Termlet Library
//
//  Created by Chuck Houpt on Wed Oct 19 2005.
//  Copyright (c) 2005-2006 Chuck Houpt. All rights reserved.
//

#import <Carbon/Carbon.h>

#import "TermletController.h"

@implementation TermletController

NSString *argument = nil;
NSString *stringEncoding = nil;
NSApplication *application;

- (void)launchTermlet {

	BOOL changed = NO;
	NSFileManager *fm = [NSFileManager defaultManager];
	NSBundle *thisBundle = [NSBundle bundleForClass:[self class]];

	NSArray *libpaths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
	NSString *appName = [thisBundle objectForInfoDictionaryKey:@"CFBundleName"];
	NSMutableString *launch = [NSString stringWithFormat:@"%@/Application Support/%@-0.7.term", [libpaths objectAtIndex:0], appName];

	NSString *templatePath;
	if ([fm fileExistsAtPath:launch]) {
		templatePath = launch;
	} else {
		templatePath = [thisBundle pathForResource:@"template" ofType:@"term"];
	}

	NSMutableDictionary *termDict = [NSDictionary dictionaryWithContentsOfFile:templatePath];
	NSArray *windowSettings = [termDict objectForKey:@"WindowSettings"];
	NSMutableDictionary *settingDict = [windowSettings objectAtIndex:0];
	
	NSString *command;
	if (argument == nil) {
		command = [NSString stringWithFormat:@"exec '%@'",[thisBundle pathForResource:@"termlet" ofType:nil]];
	} else {
		command = [NSString stringWithFormat:@"exec '%@' '%@'",[thisBundle pathForResource:@"termlet" ofType:nil], argument];
	}
	
	if (![command isEqualToString: [settingDict objectForKey:@"ExecutionString"]]) {
		[settingDict setObject:command forKey:@"ExecutionString"];
		changed = YES;
	}
	
	if (stringEncoding != nil && ![stringEncoding isEqualToString: [settingDict objectForKey:@"StringEncoding"]]) {
		[settingDict setObject:stringEncoding forKey:@"StringEncoding"];
		changed = YES;	
	}
	
	/* Strip Window location info, so new Terminal windows cascade nicely. */
	if ([settingDict objectForKey:@"WinLocULY"] || [settingDict objectForKey:@"WinLocX"] || [settingDict objectForKey:@"WinLocY"]) {
		[settingDict removeObjectForKey:@"WinLocULY"];
		[settingDict removeObjectForKey:@"WinLocX"];
		[settingDict removeObjectForKey:@"WinLocY"];
		changed = YES;
	}
	
	if (changed) [termDict writeToFile:launch atomically:YES];

	NSString *termapp = [[NSWorkspace sharedWorkspace] fullPathForApplication:@"Terminal"];
	[[NSWorkspace sharedWorkspace] openFile:launch withApplication:termapp andDeactivate:YES];
}

+ (void)initialize {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSDictionary *appDefaults = [NSDictionary
        dictionaryWithObject:@"YES" forKey:@"ShowSplash"];
    [defaults registerDefaults:appDefaults];

	NSArray *languages = [defaults objectForKey:@"AppleLanguages"];
	NSBundle *thisBundle = [NSBundle bundleForClass:[self class]];
	NSString *langEncodingPath = [thisBundle pathForResource:@"LangEncoding" ofType:@"plist"];
	
	if (langEncodingPath) {
		NSDictionary *langEncoding = [NSDictionary dictionaryWithContentsOfFile:langEncodingPath];

		int i, len = [languages count];
		for (i = 0; i < len; i++) {
			NSString *lang = [languages objectAtIndex: i];
			NSString *encoding = [langEncoding objectForKey: lang];
			if (encoding) {
				stringEncoding = [encoding retain];
				break;
			}
		}		
	}
}

- (void)applicationWillFinishLaunching:(NSNotification *)aNotification {
	application = [aNotification object];
	NSAppleEventManager *eventManager = [NSAppleEventManager sharedAppleEventManager];
    [eventManager setEventHandler:self
                      andSelector:@selector(handleURLEvent:withReplyEvent:)
                    forEventClass:kInternetEventClass
                       andEventID:(AEEventID)kAEGetURL];
    [eventManager setEventHandler:self
                      andSelector:@selector(handleURLEvent:withReplyEvent:)
                    forEventClass:'WWW!'
                       andEventID:'OURL'];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
	[[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)launch {
	// http://www.cocoadev.com/index.pl?TestForKeyDownOnLaunch

	if (GetCurrentKeyModifiers() & shiftKey) {
		[[NSUserDefaults standardUserDefaults]
			setObject:@"YES" forKey:@"ShowSplash"];
	}
	
	if (window != nil && [[NSUserDefaults standardUserDefaults] boolForKey:@"ShowSplash"]) {
		[window center];
		[window makeKeyAndOrderFront:self];
	} else {
		[self launchTermlet];
	}
}

- (void)handleURLEvent:(NSAppleEventDescriptor *)event withReplyEvent: (NSAppleEventDescriptor *)replyEvent
{
    // FIXME: Report errors (3193872).
    NSString *URLString = [[event paramDescriptorForKeyword:keyDirectObject] stringValue];
	if ([URLString hasPrefix: @"x-lynxlet://open?uri="]) {
		argument = [[URLString substringFromIndex: 21] stringByReplacingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
	} else argument = URLString;
	[self launch];
}

- (BOOL)application:(NSApplication *)app openFile:(NSString *)filename {

	argument = filename;
	[self launch];
	return YES;
}

/*
- (BOOL)application:(NSApplication *)app openFiles:(NSArray *)filenames {

	To do: implement multi-file launch
	return YES;
}
*/

- (BOOL)applicationOpenUntitledFile:(NSApplication *)theApplication {
	[self launch];
	return YES;
}

- (void)doTerminate:(NSTimer *)t {
	[application terminate: self];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	[[NSTimer scheduledTimerWithTimeInterval:
           0.5                                                 // a 100ms time interval
           target:self                                      // Target is this object
           selector:@selector(doTerminate:)       // What function are we calling
           userInfo:nil repeats:NO]                // No userinfo / repeat infinitely
           retain];                                          // No autorelease
}

- (IBAction)toggleSplash:(id)sender {
	if ([sender intValue]) {
		[[NSUserDefaults standardUserDefaults]
			setObject:@"NO" forKey:@"ShowSplash"];
	} else {
		[[NSUserDefaults standardUserDefaults]
			setObject:@"YES" forKey:@"ShowSplash"];
	}

}

- (IBAction)okSplash:(id)sender {
	[self launchTermlet]; 
}

@end
