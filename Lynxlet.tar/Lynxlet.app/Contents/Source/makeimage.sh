#!/bin/bash

# Copyright (c) 2005-2006 Chuck Houpt. All rights reserved.

set -eux

TEMP_IMAGE="$TEMP_DIR"/"$TARGETNAME"-Uncompressed.dmg
TARGET_IMAGE="$TARGET_BUILD_DIR"/"$TARGETNAME"_"$CURRENT_PROJECT_VERSION".dmg

# Remove any old image files.
rm -f "$TEMP_IMAGE"
rm -f "$TARGET_IMAGE"

# Only build an image for Deployment builds.
if [ "$BUILD_STYLE" == 'Deployment' ]
then

	# Create the temporary, uncompressed disk image.
	hdiutil create -srcfolder "$TARGET_BUILD_DIR"/"$WRAPPER_NAME" "$TEMP_IMAGE"

	# Compress the temporary image with the max gzip compression to create the final image.
	hdiutil convert "$TEMP_IMAGE" -format UDZO -imagekey zlib-level=9 -o "$TARGET_IMAGE"
	rm "$TEMP_IMAGE"

	# Internet enable the final image for easy downloading.
	hdiutil internet-enable -yes "$TARGET_IMAGE"

fi