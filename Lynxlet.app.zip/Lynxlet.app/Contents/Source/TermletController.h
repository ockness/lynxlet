//
//  TermletController.h
//  Termlet Library
//
//  Created by Chuck Houpt on Wed Oct 19 2005.
//  Copyright (c) 2005-2006 Chuck Houpt. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface TermletController : NSObject {
    IBOutlet NSWindow *window;
}

/* NSApplication delegate methods */
- (BOOL)application:(NSApplication *)app openFile:(NSString *)filename;
- (void)applicationDidFinishLaunching:(NSNotification *)aNotification;

// Actions
- (IBAction)toggleSplash:(id)sender;
- (IBAction)okSplash:(id)sender;

@end
