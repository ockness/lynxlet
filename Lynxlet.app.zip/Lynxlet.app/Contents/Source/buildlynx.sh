#!/bin/bash

# Copyright (c) 2005-2006 Chuck Houpt. All rights reserved.

set -eux

# Build gettext.
bash ./buildgettext.sh

# Setup reasonable defaults when running outside XCode.
BUILD_DIR=${BUILD_DIR:-$PWD/build}
PROJECT_DIR=${PROJECT_DIR:-$PWD}
SDKROOT_ppc=${SDKROOT_ppc:-/Developer/SDKs/MacOSX10.3.9.sdk}
SDKROOT_i386=${SDKROOT_i386:-/Developer/SDKs/MacOSX10.4u.sdk}

# Set up reasonable default when running outside mutibuild.sh
ARCH=${ARCH:-ppc}
export MULTIBUILD_NCPU=${MULTIBUILD_NCPU:-`sysctl -n hw.ncpu`}

ORIG_PATH="$PATH"

LYNX_VERSION=${1:-lynx2-8-6}
LYNX_URL=${2:-http://lynx.isc.org/current/lynx2.8.6rel.5.tar.gz}
LYNX_TARBALL=`basename $LYNX_URL`
PREFIX="$BUILD_DIR"/lynx

	SRC_DIR="$BUILD_DIR"/$ARCH/$LYNX_VERSION
	EXEC_PREFIX="$PREFIX"/$ARCH

	eval SDKROOT=\$SDKROOT_$ARCH

	if [ ! -f "$EXEC_PREFIX"/bin/lynx ]
	then

		SOURCE_CACHE="$HOME/Library/Caches/net.habilis.source"

		pushd "$BUILD_DIR"

		if [ ! -r "$SOURCE_CACHE"/$LYNX_TARBALL ]
		then
			mkdir -p "$SOURCE_CACHE"
			pushd "$SOURCE_CACHE"
			curl -sO $LYNX_URL
			popd
		fi

		if [ ! -d "$SRC_DIR" ]
		then
			rm -rf "$SRC_DIR"
			mkdir -p "$BUILD_DIR"/"$ARCH"
			pushd "$BUILD_DIR"/"$ARCH"
			tar xzf "$SOURCE_CACHE"/$LYNX_TARBALL
		# Install custom LYNX_HELPFILE support
			patch -p0 < "$PROJECT_DIR"/$LYNX_VERSION.patch
			popd
		fi

		pushd "$SRC_DIR"

		# Setup cross
		# See: http://developer.apple.com/technotes/tn2005/tn2137.html
		#export CFLAGS='-O -isysroot /Developer/SDKs/MacOSX10.2.8.sdk'
		#export LDFLAGS='-Wl,-syslibroot,/Developer/SDKs/MacOSX10.2.8.sdk'

		# Setup for 10.3+ compatibility.
		#export CFLAGS='-O -isysroot /Developer/SDKs/MacOSX10.3.9.sdk'
		#export LDFLAGS='-Wl,-syslibroot,/Developer/SDKs/MacOSX10.3.9.sdk'

		# Setup for 10.4 compatibility.
		export LDFLAGS=''
		# In the 10.4 SDK, h_addr isn't defined.
		#export CPPFLAGS="$CPPFLAGS -Dh_addr=h_addr_list[0]"


		export CFLAGS="-arch $ARCH -Os -isysroot $SDKROOT"
		export CXXFLAGS="-arch $ARCH -Os -isysroot $SDKROOT"
		export LDFLAGS="-arch $ARCH -Wl,-syslibroot,$SDKROOT"

		export CPPFLAGS="-I$BUILD_DIR/gettext/include"
		export LDFLAGS="$LDFLAGS -L$BUILD_DIR/gettext/$ARCH/lib"

		# Hmm, this could be a problem - need native arch
		PATH="$ORIG_PATH:$BUILD_DIR/gettext/$ARCH/bin"

		# Generate the missing English po file
		pushd po
		msginit --no-translator -l en
		popd

		# Force the use of NCurses 5 library, since 10.4 has a newer version.
		export LIBS="$SDKROOT/usr/lib/libncurses.5.dylib"

		time ./configure --prefix="$PREFIX" --exec-prefix="$EXEC_PREFIX" --with-ssl --enable-nls --enable-cjk --enable-japanese-utf8 --enable-default-colors

		time make -j $MULTIBUILD_NCPU install install-help
		popd

		mkdir -p "lynx/$ARCH/lib"
		cp -p gettext/"$ARCH"/lib/libintl.[0-9].dylib "lynx/$ARCH/lib"

		strip "$EXEC_PREFIX"/bin/lynx
		rm -f  "$EXEC_PREFIX"/bin/lynx.old

		# Setup S.A.C.

		#mkdir -p lynx/libexec
		#mv lynx/bin/lynx lynx/libexec
		mkdir -p "$PREFIX"/bin
		cp -p "$PROJECT_DIR"/lynx "$PREFIX"/bin
		
		popd
	fi
