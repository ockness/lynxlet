#!/bin/bash

set -eux

# Set reasonable defaults when running outside XCode
ARCHS=${ARCHS:-ppc i386}
#ARCHS=${ARCHS:-i386}

COMMAND="$@"

export MULTIBUILD_NCPU=${MULTIBUILD_NCPU:-`sysctl -n hw.ncpu`}

A=($ARCHS)
NARCH=${#A[*]}


if FANOUT=`expr $MULTIBUILD_NCPU / $NARCH`
then
	MULTIBUILD_NCPU=$FANOUT
fi

JOBS=''
export ARCH
export ARCHS
ORIG_ARCHS=$ARCHS

for ARCH in $ORIG_ARCHS
do
	ARCHS=$ARCH
	if (( $FANOUT ))
	then
		( $COMMAND ) &
		JOBS="$JOBS $!"
	else
		$COMMAND
	fi
done

wait $JOBS